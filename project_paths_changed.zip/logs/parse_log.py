import re
from datetime import datetime


def parse_log_file(filepath):
    data = {
        "start_time": None,
        "end_time": None,
        "test_oa": [],
        "test_macc": [],
        "test_miou": [],
        "class_scores": [],
        "results": {}
    }

    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    # ------------------------------------------------------------------
    # Start time:
    # Example:
    # [06/03 17:25:51 S3DIS]: Test [0]/[68] cloud ...
    # ------------------------------------------------------------------
    start_pattern = re.compile(
        r"\[(\d{2}/\d{2}\s+(\d{2}:\d{2}:\d{2}))\s+\w+\]:.*Test\s+\[\d+\]/\[\d+\]\s+cloud"
    )

    # ------------------------------------------------------------------
    # Iteration metrics:
    # Example:
    # test_oa , test_macc, test_miou : 92.51 97.11 80.10
    # ------------------------------------------------------------------
    metric_pattern = re.compile(
        r"test_oa\s*,\s*test_macc\s*,\s*test_miou\s*:\s*([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)"
    )

    # ------------------------------------------------------------------
    # Final result:
    # Example:
    # [06/03 17:56:40 S3DIS]: Best ckpt @E100,  test_oa , test_macc,
    # test_miou: 89.47 73.99 67.57
    # ------------------------------------------------------------------
    best_pattern = re.compile(
        r"\[(\d{2}/\d{2}\s+(\d{2}:\d{2}:\d{2}))\s+\w+\]:.*Best ckpt.*?"
        r"test_oa\s*,\s*test_macc\s*,\s*test_miou\s*:\s*"
        r"([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)"
    )

    i = 0
    while i < len(lines):
        line = lines[i]

        # --------------------------------------------------------------
        # Start time (first occurrence only)
        # --------------------------------------------------------------
        if data["start_time"] is None:
            m = start_pattern.search(line)
            if m:
                data["start_time"] = m.group(2)

        # --------------------------------------------------------------
        # Iteration metrics
        # --------------------------------------------------------------
        m = metric_pattern.search(line)
        if m:
            data["test_oa"].append(float(m.group(1)))
            data["test_macc"].append(float(m.group(2)))
            data["test_miou"].append(float(m.group(3)))

        # --------------------------------------------------------------
        # IoU per class
        # Can span multiple lines, e.g.
        #
        # iou per cls is: [ 97.31 98.96 ...
        #                  ...
        #                  66.72]
        # --------------------------------------------------------------
        if "iou per cls is:" in line:
            block = line

            while "]" not in block and i + 1 < len(lines):
                i += 1
                block += " " + lines[i].strip()

            nums = re.findall(r"-?\d+(?:\.\d+)?", block.split("[", 1)[1])

            if len(nums) >= 13:
                data["class_scores"].append(
                    [float(x) for x in nums[:13]]
                )

        # --------------------------------------------------------------
        # Final best checkpoint result
        # --------------------------------------------------------------
        m = best_pattern.search(line)
        if m:
            data["end_time"] = m.group(2)
            data["results"] = {
                "test_oa": float(m.group(3)),
                "test_macc": float(m.group(4)),
                "test_miou": float(m.group(5)),
            }

        i += 1

    return data


# ----------------------------------------------------------------------
# Example usage
# ----------------------------------------------------------------------
if __name__ == "__main__":
    data1 = parse_log_file("pointnetxl_proposed_0_1.txt")
    data2 = parse_log_file("baseline_pointnext_l.txt")

    #print("Start time:", data["start_time"])
    #print("End time:", data["end_time"])
    #print("Number of evaluations:", len(data["test_oa"]))
    #print("Number of class-score entries:", len(data["class_scores"]))
    #print("Final results:", data["results"])
